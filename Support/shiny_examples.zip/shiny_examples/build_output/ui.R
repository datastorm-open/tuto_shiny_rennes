shinyUI(
  fluidPage(
    fluidRow(
      lineChartOutput("mylinechart")
    )
  )
)