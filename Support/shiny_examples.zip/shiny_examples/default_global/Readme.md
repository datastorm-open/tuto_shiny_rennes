Default shiny application.
`sidebarLayout` must include a:
  -  `sidebarPanel`: thick panel at the left side, for input
  -  `mainPanel`: central part of the page, for output
With the use of a `global.R`