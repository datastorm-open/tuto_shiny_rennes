onStart <- function () {
  library(shiny)
}

server <- function(input, output) {
  
  # By default an output is reactive when it depends on inputs
  output$distPlot <- renderPlot({
    
    # generate bins based on input$bins from ui.R
    # for debuging purposes, it is better to define variables which depend on the inputs
    # outside the function. Thus you will able to locate the problem
    # (check the variable or give it a default value)
    nbBreaks <- input$bins
    x    <- faithful[, 2]
    bins <- seq(from = min(x), to = max(x), length.out = nbBreaks + 1)
    
    # draw the histogram with the specified number of bins
    hist(x = x, breaks = nbBreaks, col = 'darkgray', border = 'white')
    
  })
  
}

ui <- fluidPage(
  
  # Application title: top of the page
  titlePanel("Old Faithful Geyser Data"),
  
  # sidebarLayout must include a:
  # -  sidebarPanel: thick panel at the left side
  # -  mainPanel: central part of the page
  sidebarLayout(
    
    # Sidebar with a slider input for number of bins
    sidebarPanel(
      sliderInput(inputId = "bins",
                  label = "Number of bins:",
                  min = 1,
                  max = 50,
                  value = 30)
    ),
    
    # Central part of the page
    mainPanel(
      # Show a plot of the generated distribution
      plotOutput("distPlot")
    )
  )
)

shinyApp(ui = ui, server = server, onStart = onStart)
