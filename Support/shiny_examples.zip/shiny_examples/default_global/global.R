# all packages / variables / functions loaded in global.R 
# are visible in ui.R and in server.R

library(shiny)