A `navbarPage` can contain any type of shiny layout.

This example illustrates the case where a `tabPanel` includes a `sidebarLayout`.

The depth is infinite ! For instance we could define another `tabsetPanel` in the `mainPanel`.

Just remember that layout functions called in UI writes HTML code.