library(shiny)

# Ici on cree une variable globale a TOUS les utilisateurs de l'application
# cette variable sera donc commune et accessible par toutes les fonctions du server.
# Un seul emplacement memoire sera utilise.

# Decommenter l'un des cas suivants pour tester

# Cas d'une seule ligne de code :
# values <- get(x = "iris", pos = "package:datasets")[,1]

# Cas de plusieurs lignes de code :

# on cree une fonction globale a tous les utilisateurs
getValues <- function() {
  iris <- get(x = "iris", pos = "package:datasets")
  iris[,1]
}

# On creer la variable globale.
values <- getValues()
# Dans ce cas on peut aussi decider que la variable doit etre unique a chaque utilisateur
# par consequent, on peut la declarer dans la fonction 'shinyServer'

shinyServer(function(input, output) {
  
  # On declare la variable dans le server;
  # dans ce cas, chaque utilisateur aura sa propre variable
  # et donc son propre emplacement memoire
  #
  # values <- getValues()
  
  output$hist <- renderPlot({
    x <- values
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values
    boxplot(x)
  })
})
