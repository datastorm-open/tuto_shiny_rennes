library(shiny)

shinyServer(function(input, output) {
  
  # Dans cet exemple, on cree une variable qui sera evaluee
  # a chaque connexion a l'application,
  # elle est disponible a toutes les fonctions du server
  # C'est une bonne alternative a l'expression reactive
  
  # on peut faire comme cela dans ce cas (une ligne de code)
  values <- get(x = "iris", pos = "package:datasets")[,1]
  
  # dans le cas de plusieurs lignes de codes necessaires,
  # on fera plutot comme l'exemple 3
  
  output$hist <- renderPlot({
    x <- values
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values
    boxplot(x)
  })
})
