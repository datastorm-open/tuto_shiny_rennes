library(shiny)

shinyServer(function(input, output) {
  
  # On cree une variable reactive pour renvoyer les donnees
  # ici, il n'y a pas de dependance aux inputs ;
  # par consequent cela permet simplement de factoriser le code.
  # L'expression est evaluee une seule fois, a chaque connection a l'application
  # 
  # Pour ne pas surcharger l'exemple, une ligne de code est necessaire pour
  # obtenir le resultat, il n'y a pas non plus de probleme de temps.
  # Cependant, on peut imaginer avoir du code long à s'executer,
  # ou avoir plusieurs traitements necessaires avant de rendre le resultat
  # cela legitimerait l'utilisation d'un reactif et encore...
  #
  # Si la valeur de la variable est toujours la meme, pour tous les utilisateurs
  # on peut privilegier de creer une variable globale dans le server
  # -> voir exemple 2
  
  values <- reactive({
    get(x = "iris", pos = "package:datasets")[, 1]
  })
  
  output$hist <- renderPlot({
    x <- values()
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values()
    boxplot(x)
  })
})
