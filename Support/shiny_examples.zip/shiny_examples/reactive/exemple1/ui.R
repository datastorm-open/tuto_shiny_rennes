library(shiny)

shinyUI(fluidPage(
  # dans l'ui, on affiche simplement l'histogramme et le boxplot
  plotOutput("hist"),
  plotOutput("box")
))
