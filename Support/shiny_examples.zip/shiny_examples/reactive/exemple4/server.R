library(shiny)

shinyServer(function(input, output) {
  
  # On cree une variable reactive pour renvoyer les donnees
  # ici, il y a une dependance aux input, par consequent:
  #
  #  - la variable sera evaluee au lancement de l'application
  #  - la variable sera reevaluee a chaque fois que les inputs changeront de valeur
  # 
  # On comprend donc que toutes les fonctions dependantes de cette varaiable reactive seront
  # reevaluees a chaque fois que les inputs contenus dans l'expression reactive
  # changeront de valeur.
  #
  # C'est l'interet principal d'une expression reactive !
  values <- reactive({
    colonne <- input$colonne
    get(x = "iris", pos = "package:datasets")[, colonne]
  })
  
  
  output$hist <- renderPlot({
    x <- values()
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values()
    boxplot(x)
  })
})
