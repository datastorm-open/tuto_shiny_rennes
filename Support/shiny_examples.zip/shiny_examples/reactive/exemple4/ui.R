library(shiny)

shinyUI(fluidPage(
  
  # On cree un slider pour que l'utilisateur puisse choisir la colonne
  sliderInput(
    inputId = "colonne",
    label = "Colonne",
    min = 1,
    max = 4,
    value = 2
  ),
  
  # on affiche les graphiques
  plotOutput("hist"),
  plotOutput("box")
))
