library(shiny)
shinyApp(
  ui = fluidPage(
    sliderInput(inputId = "slide", label = "Test me !", min = 0, max = 10, value = 2),
    dataTableOutput(outputId = "table")
  ),
  server = function(input, output, session) {
    data("iris")
    
    isSliderEven <- reactive({
      input$slide %% 2
    })
    
    # validate on reactive expression
    iris_reactive <- reactive({
      shiny::validate(
        need(isSliderEven() == 0, "Not even value...")
      )
      iris
    })
    
    output$table <- renderDataTable({
      iris_reactive()
    })
  }
)