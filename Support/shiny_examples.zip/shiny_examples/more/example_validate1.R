library(shiny)
shinyApp(
  ui = fluidPage(
    sliderInput(inputId = "slide", label = "Test me !", min = 0, max = 5, value = 1),
    dataTableOutput(outputId = "table")
  ),
  server = function(input, output, session) {
    data("iris")
    
    # validate on input value
    iris_reactive <- reactive({
      shiny::validate(
        need(input$slide > 2, "Not enough !")
      )
      iris
    })
    
    output$table <- renderDataTable({
      iris_reactive()
    })
  }
)