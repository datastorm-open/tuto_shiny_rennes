library(shiny)

shinyUI(fluidPage(

  # Application title: top of the page
  titlePanel("Old Faithful Geyser Data"),

  # sidebarLayout must include a:
  # -  sidebarPanel: thick panel at the left side
  # -  mainPanel: central part of the page
  sidebarLayout(
    
    # Sidebar with a slider input for number of bins
    sidebarPanel(
      sliderInput(inputId = "bins",
                  label = "Number of bins:",
                  min = 1,
                  max = 50,
                  value = 30)
    ),

    # Central part of the page
    mainPanel(
      # Show a plot of the generated distribution
      plotOutput("distPlot")
    )
  )
))
