# Run this app with code !
# runApp("navbarPage", display.mode = "showcase")

library(shiny)

shinyServer(function(input, output, session) {
  
  # By default an output is reactive when it depends on inputs
  output$distPlot <- renderPlot({
    
    # generate bins based on input$bins from ui.R
    # for debuging purposes, it is better to define variables which depend on the inputs
    # outside the function. Thus you will able to locate the problem
    # (check the variable or give it a default value)
    nbBreaks <- input$bins
    x    <- faithful[, 2]
    bins <- seq(from = min(x), to = max(x), length.out = nbBreaks + 1)
    
    # draw the histogram with the specified number of bins
    hist(x = x, breaks = nbBreaks, col = 'darkgray', border = 'white')
    
  })
  
  # the two followings ouptput are associated to 'dataTableOuput' (ui)
  # the results will be default 
  
  output$table <- renderDataTable(
    faithful
  )
  
  output$summary <- renderDataTable(
    summary(faithful)
  )
  
})