This app illustrates the infinite possibility to organise a web page based on `fluidPage`.

We recommend to always set a column (even with width = 12) in a `fluidRow`. The problem does not occur in the case of multiple columns.