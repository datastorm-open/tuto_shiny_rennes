#' @examples
#' # Run this app with with the following code line !
#' runApp("fluidPage1")

library(shiny)

# Create a page that contains a top level navigation bar that can be used to
# toggle a set of tabPanel elements.

fluidPage(
  title = "fluidPage1",
  
  br(),
  # Create a tabset that contains tabPanel elements.
  # Tabsets are useful for dividing output into multiple independently viewable sections.
  tabsetPanel(
    type = "pill",
    
    tabPanel(
      title = "Plot",
      br(),
      sidebarLayout(
        # Sidebar with a slider input for number of bins
        sidebarPanel(
          sliderInput(inputId = "bins",
                      label = "Number of bins:",
                      min = 1,
                      max = 50,
                      value = 30)
        ),
        
        # Central part of the page
        mainPanel(
          # Show a plot of the generated distribution
          plotOutput("distPlot")
        )
      )
    ),
    
    tabPanel(
      title = "Summary",
      br(),
      dataTableOutput(outputId = "summary")
    ),
    
    tabPanel(
      title = "Table",
      br(),
      dataTableOutput(outputId = "table")
    ),
    
    # The navbarMenu function can be used to create an embedded menu within the navbar
    # that in turns includes additional tabPanels (see example below).
    navbarMenu(
      title = "More",
      tabPanel(
        title = "About data",
        br(),
        h5("Waiting time between eruptions and the duration of the eruption for
         the Old Faithful geyser in Yellowstone National Park, Wyoming, USA."),
        h3("Format"),
        div("A data frame with 272 observations on 2 variables."),
        div("[,1]	eruptions	numeric	Eruption time in mins"),
        div("[,2]	waiting	numeric	Waiting time to next eruption (in mins)"),
        h3("Details"),
        div(align = "left",
            "A closer look at faithful$eruptions reveals that these are heavily",
            "rounded times originally in seconds, where multiples of 5 are more frequent",
            "than expected under non-human measurement. For a better version of the eruption times,",
            "see the example below.",
            "There are many versions of this dataset around: Azzalini and Bowman (1990) use a more complete version."
        )
      ),
      tabPanel(
        title = "References",
        br(),
        div("Härdle, W. (1991) Smoothing Techniques with Implementation in S. New York: Springer."),
        div("Azzalini, A. and Bowman, A. W. (1990). A look at some data on the Old Faithful geyser. Applied Statistics 39, 357–365.")
      )
    )
  ),
  
  div(align = "center",
      br(),br(),
      div(align = "center", "©DataKnowledge \"presentation R-Shiny\", octobre 2015"),
      img(src = "img/logo_DataK.png"),
      br(),
      a(href = "http://www.datak.fr", "datak.fr")
  )
)