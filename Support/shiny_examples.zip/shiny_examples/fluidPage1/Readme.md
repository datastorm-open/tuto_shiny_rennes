Quick exemple to illustrate a "navbar" layout with `fluidPage`.
It is clearly equivalent to the example using `navbarPage` thanks to the use of `tabsetPanel`.
The latter can contain both `tabPanel` and `navbarMenu`.