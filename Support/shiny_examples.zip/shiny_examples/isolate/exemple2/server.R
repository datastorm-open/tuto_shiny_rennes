library(shiny)

shinyServer(function(input, output) {
  
  # On cree une variable reactive pour renvoyer les donnees
  # ici, il y a une dependance aux input, par consequent:
  #
  #  - la variable sera evaluee au lancement de l'application
  #  - la variable sera reevaluee a chaque fois que les inputs changeront de valeur
  # 
  # La variable reactive depend de deux inputs,
  # On a isole 'input$size',
  # par consequent, elle sera reevaluee uniquement quand la valeur 'input$colonne' changera
  #
  # Il en sera de meme pour toutes les fonctions qui dépendront de cette variables reactive
  # ici, il s'agit des graphiques
  values <- reactive({
    colonne <- input$colonne
    x <- get(x = "iris", pos = "package:datasets")[, colonne]
    obs <- sample(x = x, size = isolate(input$size))
    x[obs]
  })
  
  output$hist <- renderPlot({
    x <- values()
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values()
    boxplot(x)
  })
})
