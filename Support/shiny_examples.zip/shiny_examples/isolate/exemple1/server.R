library(shiny)

shinyServer(function(input, output) {
  
  # On cree une variable reactive pour renvoyer les donnees
  # ici, il y a une dependance aux input, par consequent:
  #
  #  - la variable sera evaluee au lancement de l'application
  #  - la variable sera reevaluee a chaque fois que les inputs changeront de valeur
  # 
  # La variable reactive depend de deux inputs,
  # Sans 'isolate', elle sera reevaluee quand les valeurs suivantes changeront:
  #   - input$colonne
  #   - input$size
  #
  values <- reactive({
    colonne <- input$colonne
    x <- get(x = "iris", pos = "package:datasets")[, colonne]
    obs <- sample(x = x, size = input$size)
    x[obs]
  })
  
  output$hist <- renderPlot({
    x <- values()
    hist(x)
  })
  
  output$box <- renderPlot({
    x <- values()
    boxplot(x)
  })
})
