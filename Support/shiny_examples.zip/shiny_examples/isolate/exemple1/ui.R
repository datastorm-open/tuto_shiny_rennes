library(shiny)

shinyUI(fluidPage(
  
  # On cree un slider pour que l'utilisateur puisse choisir la colonne
  sliderInput(
    inputId = "colonne",
    label = "Colonne",
    min = 1,
    max = 4,
    value = 2
  ),
  
  # on cree un deuxieme slider input pour fixer le nombre d'observations
  sliderInput(
    inputId = "size",
    label = "Colonne",
    min = 20,
    max = 150,
    value = 100
  ),
  
  # on affiche les graphiques
  plotOutput("hist"),
  plotOutput("box")
))
